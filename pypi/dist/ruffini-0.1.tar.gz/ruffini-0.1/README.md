#Ruffini

To see the documentation, please [click here](https://gianluparri03.github.io/ruffini).

Instead, if you want to see the source, [click here](https://github.com/gianluparri03/ruffini).

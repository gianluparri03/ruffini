from setuptools import setup

setup(
    name="ruffini",
    version="0.1",
    description="Monomials, Polynomials and lot more!",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Gianluca Parri",
    author_email="gianlucaparri03@gmail.com",
    url="https://github.com/gianluparri03/ruffini",
    packages=["ruffini"],
    license="MIT",
)
